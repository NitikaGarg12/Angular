var message = "Hello To All Welcome to TypeScript";
console.log(message);
